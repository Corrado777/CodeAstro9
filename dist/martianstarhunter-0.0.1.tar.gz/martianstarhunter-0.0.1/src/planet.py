class Planet():
    def __init__(self, label, period, radius, distance, tilt, ra, dec):
        self.label = label
        self.period = period
        self.radius = radius
        self.distance = distance
        self.tilt = tilt
        self.ra = ra
        self.dec = dec
        