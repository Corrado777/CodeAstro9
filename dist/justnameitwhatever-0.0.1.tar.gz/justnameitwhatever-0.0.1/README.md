# CodeAstro9
Project repository for code astro group 9
Authors: Anthony Girmenia, Elena González Prieto, Ahmed Taha, Josh Weston


End goal: Sky chart generator for observing on Mars.

Stretch goals: Other planets, other visualisation techniques

Pipeline plan:

  -Object to be observed
  -Given time
  -Our location (position and planet)

In the first instance, can calculate the observation of a specific object from a specific location, then generalise

  -Visualisation (observer chart) - altitude versus time
  -Data
  -potential stretch - position of sun/earth/other planets


Dependencies:
  -celestial coordinates/ephemeris catalogues
  -time conversion process/database



Day-to-day plan:

Monday
  -Initial plan
  
Tuesday
- Finish functions 

Wednesday
- See Chicago 

Thursday

Friday
  -Present!
