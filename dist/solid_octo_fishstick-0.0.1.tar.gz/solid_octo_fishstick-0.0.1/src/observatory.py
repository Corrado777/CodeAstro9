class Observatory():
    def __init__(self, label, latitude, longitude, altitude):
        self.label = label
        self.latitude = latitude
        self.longitude = longitude
        self.altitude = altitude